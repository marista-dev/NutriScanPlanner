# datasetss > 2023-11-17 2:52am
https://universe.roboflow.com/ingredientsdetecting/datasetss-6go9m

Provided by a Roboflow user
License: CC BY 4.0

