# datasetss > 2023-11-17 4:38pm
https://universe.roboflow.com/ingredientsdetecting/datasetss-6go9m

Provided by a Roboflow user
License: CC BY 4.0

